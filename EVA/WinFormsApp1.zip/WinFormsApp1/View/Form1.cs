using System.Windows.Forms;
using WinFormsApp1.Model;


namespace WinFormsApp1;

public enum Direction { Up, Down, Right, Left }

public partial class Form1 : Form
{
    IGameModel _model;

    public Form1(IGameModel model)
    {
        InitializeComponent();
        _model = model;
        _model.IllegalMove += ShowMessageBox;
        _model.GameLoaded += Model_GameLoaded;
        _model.BallMoved += Model_BallMoved;
        _model.GameFinished += Model_GameFinished;
        loadToolStripMenuItem.Click += OpenGame;
        KeyPreview = true;
        KeyDown += Form1_KeyDown;
        DoubleBuffered = true;
        ResizeRedraw = true;
    }

    private Image _ballImage = Image.FromFile(Path.Combine(AppContext.BaseDirectory, "cleanball.png"));
    private async void OpenGame(object? sender, EventArgs e)
    {
        using (OpenFileDialog dialog = new OpenFileDialog())
        {
            dialog.Filter = "P�lyaf�jlok (*.txt)|*.txt";
            dialog.InitialDirectory =
                Path.Combine(AppContext.BaseDirectory, "Levels");

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                await _model.LoadGame(dialog.FileName);
            }
        }
    }

    private void Model_GameFinished(object? sender, EventArgs e)
    {
        MessageBox.Show("Victory!");
    }

    private void ShowMessageBox(object? sender, String s)
    {
        MessageBox.Show(this, s);
    }

    private void Form1_KeyDown(object? sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Right)
        {
            _model.MoveBall(Direction.Right);
        }
        if (e.KeyCode == Keys.Left)
        {
            _model.MoveBall(Direction.Left);
        }
        if (e.KeyCode == Keys.Up)
        {
            _model.MoveBall(Direction.Up);
        }
        if (e.KeyCode == Keys.Down)
        {
            _model.MoveBall(Direction.Down);
        }
    }

    private void Model_GameLoaded(object? sender, EventArgs e)
    {
        Paint += PaintField;
        Invalidate();
        //ezutan kezdd el csak rajzolni
    }

    private void Model_BallMoved(object? sender, Point e)
    {
        Invalidate();
    }

    private void PaintField(object? sender, PaintEventArgs e)
    {
        Graphics g = e.Graphics;
        int cellSizeX = ClientSize.Width / _model.N;
        int cellSizeY = ClientSize.Height / _model.N;

        for (int x = 0; x < _model.N; x++)
        {
            for (int y = 0; y < _model.N; y++)
            {
                if (_model.GetFieldType(new Point(x, y)) == Persistence.FieldType.Canvas)
                {
                    Rectangle rect = new Rectangle(x * cellSizeX, y * cellSizeY, cellSizeX, cellSizeY);
                    g.FillRectangle(Brushes.Green, rect);
                }

                if (_model.GetFieldType(new Point(x, y)) == Persistence.FieldType.PaintedCanvas)
                {
                    Rectangle rect = new Rectangle(x * cellSizeX, y * cellSizeY, cellSizeX, cellSizeY);
                    g.FillRectangle(Brushes.Purple, rect);
                }

                if (_model.GetFieldType(new Point(x, y)) == Persistence.FieldType.Wall)
                {
                    Rectangle rect = new Rectangle(x * cellSizeX, y * cellSizeY, cellSizeX, cellSizeY);
                    g.FillRectangle(Brushes.Gray, rect);
                }

                if (_model.GetFieldType(new Point(x, y)) == Persistence.FieldType.ClosedGate)
                {
                    Rectangle rect = new Rectangle(x * cellSizeX, y * cellSizeY, cellSizeX, cellSizeY);
                    g.FillRectangle(Brushes.Brown, rect);
                }

                if (_model.GetFieldType(new Point(x, y)) == Persistence.FieldType.OpenGate)
                {
                    Rectangle rect = new Rectangle(x * cellSizeX, y * cellSizeY, cellSizeX, cellSizeY);
                    g.FillRectangle(Brushes.Black, rect);
                }

                if (_model.GetFieldType(new Point(x, y)) == Persistence.FieldType.Switch)
                {
                    Rectangle rect = new Rectangle(x * cellSizeX, y * cellSizeY, cellSizeX, cellSizeY);
                    g.FillRectangle(Brushes.Yellow, rect);
                }

                Rectangle ball = new Rectangle(_model.BallPos.X * cellSizeX, _model.BallPos.Y * cellSizeY, cellSizeX / 2, cellSizeY / 2);
                g.DrawImage(_ballImage, ball);
            }
        }
    }
}