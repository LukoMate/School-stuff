﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1.Persistence;

public class Table
{
    public FieldType[,] GameTable {  get; private set; }
    public int _size;
    public Table(int size)
    {
        GameTable = new FieldType[size, size]; //ezt toltjuk fel a filedataaccessben

        _size = size;
    }

}
