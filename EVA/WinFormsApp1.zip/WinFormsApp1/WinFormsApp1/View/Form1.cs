using System.Timers;
using System.Windows.Forms;
using WinFormsApp1.Model;
using static WinFormsApp1.Model.GameModel;


namespace WinFormsApp1;

public enum Direction { Up, Down, Right, Left }

public partial class Form1 : Form
{
    IGameModel _model;

    public Form1(IGameModel model)
    {
        InitializeComponent();
        _model = model;
        _model.IllegalMove += ShowMessageBox;
        _model.GameLoaded += Model_GameLoaded;
        _model.BallMoved += Model_BallMoved;
        _model.GameWon += Model_GameWon;
        _model.GameStarted += Model_GameStarted;
        _model.ClickCounterChanged += Model_ClickCounterChanged;
        _model.TimeElapsed += Model_TimeElapsed;
        loadToolStripMenuItem.Click += OpenGame;
        KeyPreview = true;

        DoubleBuffered = true;
        ResizeRedraw = true;
    }

    private Image _ballImage = Image.FromFile(Path.Combine(AppContext.BaseDirectory, "cleanball.png"));


    private void Model_GameStarted(object? sender, int e)
    {
        StartGameButton.Visible = false;

        KeyDown += Form1_KeyDown;
        label1.Visible = true;
        label2.Visible = true;
    }

    private void Model_TimeElapsed(object? sender, ElapsedTimeEventArgs e)
    {
        label2.Text = $"Elapsed Time: {e.Minutes}:{e.Seconds}";
    }

    private void Model_ClickCounterChanged(object? sender, int e)
    {
        label1.Text = $"Click Count: {e}";

    }

    private void Model_GameWon(object? sender, EventArgs e)
    {
        MessageBox.Show("Victory!");
        KeyDown -= Form1_KeyDown;
    }

    private void Model_GameLoaded(object? sender, EventArgs e)
    {
        StartGameButton.Visible = true;
        Paint += PaintField;
        Invalidate();
        //ezutan kezdd el csak rajzolni
        label1.Visible = false;
        label2.Visible = false;
    }

    private void Model_BallMoved(object? sender, Point e)
    {
        Invalidate();
    }

    private void ShowMessageBox(object? sender, String s)
    {
        MessageBox.Show(this, s);
    }

    private void StartGameButton_Click(object sender, EventArgs e)
    {
        pauseToolStripMenuItem.Enabled = true;
        _model.StartNewGame();
    }

    private async void OpenGame(object? sender, EventArgs e)
    {
        using (OpenFileDialog dialog = new OpenFileDialog())
        {
            dialog.Filter = "P�lyaf�jlok (*.txt)|*.txt";
            dialog.InitialDirectory =
                Path.Combine(AppContext.BaseDirectory, "Levels");

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                await _model.LoadGame(dialog.FileName);
            }
        }
    }

    private void Form1_KeyDown(object? sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Right)
        {
            _model.MoveBall(Direction.Right);
        }
        if (e.KeyCode == Keys.Left)
        {
            _model.MoveBall(Direction.Left);
        }
        if (e.KeyCode == Keys.Up)
        {
            _model.MoveBall(Direction.Up);
        }
        if (e.KeyCode == Keys.Down)
        {
            _model.MoveBall(Direction.Down);
        }
    }



    private void PaintField(object? sender, PaintEventArgs e)
    {
        if (_model.N == 0)
            return;

        Graphics g = e.Graphics;
        int top = menuStrip1.Height;
        int availableHeight = ClientSize.Height - top;
        int cellSizeX = ClientSize.Width / _model.N;
        int cellSizeY = availableHeight / _model.N;

        for (int x = 0; x < _model.N; x++)
        {
            for (int y = 0; y < _model.N; y++)
            {
                Rectangle rect = new Rectangle(x * cellSizeX, top + y * cellSizeY, cellSizeX, cellSizeY);

                if (_model.GetFieldType(new Point(x, y)) == Persistence.FieldType.Canvas)
                {
                    g.FillRectangle(Brushes.Green, rect);
                }

                if (_model.GetFieldType(new Point(x, y)) == Persistence.FieldType.PaintedCanvas)
                {
                    g.FillRectangle(Brushes.Purple, rect);
                }

                if (_model.GetFieldType(new Point(x, y)) == Persistence.FieldType.Wall)
                {
                    g.FillRectangle(Brushes.Gray, rect);
                }

                if (_model.GetFieldType(new Point(x, y)) == Persistence.FieldType.ClosedGate)
                {
                    g.FillRectangle(Brushes.Brown, rect);
                }

                if (_model.GetFieldType(new Point(x, y)) == Persistence.FieldType.OpenGate)
                {
                    g.FillRectangle(Brushes.Black, rect);
                }

                if (_model.GetFieldType(new Point(x, y)) == Persistence.FieldType.Switch)
                {
                    g.FillRectangle(Brushes.Yellow, rect);
                }
            }
        }

        Rectangle ball = new Rectangle(
            _model.BallPos.X * cellSizeX,
            top + _model.BallPos.Y * cellSizeY,
            cellSizeX / 2, cellSizeY / 2);
        g.DrawImage(_ballImage, ball);
    }
    private void pauseToolStripMenuItem_Click(object sender, EventArgs e)
    {
        _model.PauseGame();
        var page = new TaskDialogPage
        {
            Caption = "Pause",
            Heading = "Game paused",
            Buttons = { new TaskDialogButton("Continue") }
        };
        TaskDialog.ShowDialog(this, page);
        _model.PauseGame();
    }
}
