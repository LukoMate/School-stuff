﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WinFormsApp1.Persistence;
using static WinFormsApp1.Model.GameModel;

namespace WinFormsApp1.Model
{
    public interface IGameModel
    {
        Point BallPos { get; }
        int N { get; }
        Table Table { get; }

        Task LoadGame(string s);
        public Point GetFieldLocation(FieldType t);
        public FieldType GetFieldType(Point p);
        public int EmptyFieldCount();
        public void MoveBall(Direction d);
        public void StartNewGame();
        public void GameFinished();
        public void PauseGame();

        public event EventHandler<EventArgs>? GameLoaded;
        public event EventHandler<Point>? BallMoved;
        public event EventHandler<String>? IllegalMove;
        public event EventHandler<EventArgs>? GameWon;
        public event EventHandler<int>? GameStarted;
        public event EventHandler<int>? ClickCounterChanged;
        public event EventHandler<ElapsedTimeEventArgs>? TimeElapsed;

    }
}
