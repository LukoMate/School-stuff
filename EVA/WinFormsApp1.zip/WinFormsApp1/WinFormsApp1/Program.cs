using WinFormsApp1.Model;
using WinFormsApp1.Persistence;

namespace WinFormsApp1
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.

            System.Windows.Forms.Timer timer = new();
            timer.Interval = 1000;
            FileDataAccess fileDataAccess = new FileDataAccess();
            IGameModel model = new GameModel(fileDataAccess, timer);
            ApplicationConfiguration.Initialize();
            Application.Run(new Form1(model));
        }
    }
}