﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WinFormsApp1.Persistence;

namespace WinFormsApp1.Model
{
    public interface IGameModel
    {
        Point BallPos { get; }
        int N { get; }
        Table Table { get; }

        //void StartNewGame();
        //void Pause();
        //void SaveGame();
        Task LoadGame(string s);
        public Point GetFieldLocation(FieldType t);
        public FieldType GetFieldType(Point p);
        public int EmptyFieldCount();
        public void MoveBall(Direction d);

        public event EventHandler<EventArgs>? GameLoaded;
        public event EventHandler<Point>? BallMoved;
        public event EventHandler<String>? IllegalMove;
        public event EventHandler<EventArgs>? GameFinished;
    }
}
