﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WinFormsApp1.Persistence;

namespace WinFormsApp1.Model
{
    public class GameModel : IGameModel
    {
        private FileDataAccess _fileDataAccess;
        public Table Table { get; private set; }  //tabla amivel dolgozunk
        public int N { get; private set; }
        public Point BallPos { get; private set; }

        public int emptyFieldsNum;

        #region EVENTS

        public event EventHandler<EventArgs>? GameLoaded;  //lehet eleg emptyargs
        public event EventHandler<Point>? BallMoved;
        public event EventHandler<String>? IllegalMove;
        public event EventHandler<EventArgs>? GameFinished;

        #endregion

        #region METHODS
        public GameModel(FileDataAccess fileDataAccess)
        {
            _fileDataAccess = fileDataAccess;
        }

        public int EmptyFieldCount()
        {
            int counter = 1; //start mezothozzaadjuk
            for (int row = 0; row < N; row++)
            {
                for (int col = 0; col < N; col++)
                {
                    if (Table.GameTable[row, col] == FieldType.Canvas)
                    {
                        counter++;
                    }
                }
            }
            return counter; //ez megad egy szamot (pl 33)
        }

        public int PaintedFieldCount()
        {
            int counter = 0;
            for (int row = 0; row < N; row++)
            {
                for (int col = 0; col < N; col++)
                {
                    if (Table.GameTable[row, col] == FieldType.PaintedCanvas)
                    {
                        counter++;
                    }
                }
            }
            return counter;
        }

        public bool IsGameFinished()
        {
            if (emptyFieldsNum == PaintedFieldCount())
            {
                return true;
            }
            return false;
        }

        public Point GetFieldLocation(FieldType t)
        {
            for (int row = 0; row < N; row++)
            {
                for (int col = 0; col < N; col++)
                {
                    if (Table.GameTable[row, col] == t)
                    {
                        return new Point(col, row);
                    }
                }
            }
            throw new InvalidOperationException("A keresett FieldType nem található a játéktáblában.");
        }

        public FieldType GetFieldType(Point p)
        {
            return Table.GameTable[p.Y, p.X];
        }

        public void MoveBall(Direction d)
        {
            Point next = BallPos;
            switch (d)
            {
                case Direction.Left:
                    next = new Point(BallPos.X - 1, BallPos.Y);
                    break;

                case Direction.Right:
                    next = new Point(BallPos.X + 1, BallPos.Y);
                    break;

                case Direction.Up:
                    next = new Point(BallPos.X, BallPos.Y - 1);
                    break;

                case Direction.Down:
                    next = new Point(BallPos.X, BallPos.Y + 1);
                    break;
            }

            if (next.X < 0 || next.Y < 0 || next.X >= N || next.Y >= N)
            {
                return;
            }

            else if (GetFieldType(next) == FieldType.Wall)
            {
                IllegalMove?.Invoke(this, "Illegal move, there is a wall!");
                return;
            }

            else if (GetFieldType(next) == FieldType.ClosedGate)
            {
                IllegalMove?.Invoke(this, "Illegal move, there is a closed gate!");
                return;
            }

            else if (GetFieldType(next) == FieldType.Switch)
            {
                SwitchSequence();
            }
        
            else if (GetFieldType(next) == FieldType.Canvas)
            {
                Table.GameTable[next.Y, next.X] = FieldType.PaintedCanvas;
            }

            BallPos = next; //ha ezeken tuljutunk akkor csak adjuk at mivel a lepes sikeres
            BallMoved?.Invoke(this, BallPos);

            if (IsGameFinished())
            {
                GameFinished?.Invoke(this, EventArgs.Empty);
            }
        }

        public void SwitchSequence()
        {
            for (int row = 0; row < N; row++)
            {
                for (int col = 0; col < N; col++)
                {
                    if (Table.GameTable[row, col] == FieldType.ClosedGate)
                    {
                        Table.GameTable[row, col] = FieldType.OpenGate;
                    }
                    else if (Table.GameTable[row, col] == FieldType.OpenGate)
                    {
                        Table.GameTable[row, col] = FieldType.ClosedGate;
                    }
                }
            }
            //ballmoved invoke alapbol lefut ekkor nem kell tobb
        }

        public async Task LoadGame(string path) //ez visszaad nekunk egy adattal feltoltott tablat
        {
            Table = await _fileDataAccess.LoadAsync(path);
            N = Table._size;

            BallPos = GetFieldLocation(FieldType.Start);  //ide kell irni mert itt latjuk a valodi tablat, ctorban azt irja h might be null
            Table.GameTable[BallPos.Y, BallPos.X] = FieldType.PaintedCanvas;
            emptyFieldsNum = EmptyFieldCount();
            GameLoaded?.Invoke(this, EventArgs.Empty);
        }

        #endregion
    }
}