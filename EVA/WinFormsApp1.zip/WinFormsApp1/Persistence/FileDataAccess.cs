﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace WinFormsApp1.Persistence
{
    public enum FieldType
    {
        Start, Wall, Switch, ClosedGate, OpenGate, Canvas, PaintedCanvas
    }
    public class FileDataAccess
    {
        public int N { get; private set; }
        public async Task<Table> LoadAsync(String path)
        {
            try
            {
                using (StreamReader reader = new StreamReader(path)) // fájl megnyitása
                {
                    N = int.Parse(await reader.ReadLineAsync() ?? string.Empty);
                    //allLines = line.Split(' '); nem kell mert nincs space nalunk
                    Table table = new Table(N);

                    for (int row = 0; row < N; row++)
                    {
                        string line = await reader.ReadLineAsync() ?? string.Empty;
                        for (int col = 0; col < N; col++)
                        {
                            switch (line[col])
                            {
                                case '.':
                                    table.GameTable[row, col] = FieldType.Canvas; break;

                                case '#':
                                    table.GameTable[row, col] = FieldType.Wall; break;

                                case 'S':
                                    table.GameTable[row, col] = FieldType.Start; break;

                                case 'K':
                                    table.GameTable[row, col] = FieldType.Switch; break;

                                case 'G':
                                    table.GameTable[row, col] = FieldType.OpenGate; break;

                                case 'g':
                                    table.GameTable[row, col] = FieldType.ClosedGate; break;

                            }
                        }

                    }
                    return table;
                }
            }
            catch 
            {
                throw new Exception("Error at loading");
            }
        }



            //public async Task<Table> SaveAsync(String path, Table table)
            //{

            //}

        }

///regi moveball metodus, ez le lett cserelve
    //public void MoveBall2(Direction d)
    //{
    //    switch (d)
    //    {
    //        case Direction.Right:

    //            if (!IsInside(new Point(BallPos.X + 1, BallPos.Y)))
    //            {
    //                return;
    //            }
    //            //if X+1 not a wall
    //            if (GetFieldType(new Point(BallPos.X + 1, BallPos.Y)) == FieldType.Wall)
    //            {
    //                IllegalMove?.Invoke(this, "Illegal move, there is a wall!");
    //                return;
    //            }

    //            else if (GetFieldType(new Point(BallPos.X + 1, BallPos.Y)) == FieldType.ClosedGate)
    //            {
    //                IllegalMove?.Invoke(this, "Illegal move, there is a closed gate!"); //ehelyett lehetne h pirossal megvillogtatjuk az adott blokkot
    //                return;
    //            }

    //            else if (GetFieldType(new Point(BallPos.X + 1, BallPos.Y)) == FieldType.Canvas ||
    //                GetFieldType(new Point(BallPos.X + 1, BallPos.Y)) == FieldType.Start ||
    //                GetFieldType(new Point(BallPos.X + 1, BallPos.Y)) == FieldType.PaintedCanvas)
    //            {
    //                if (GetFieldType(new Point(BallPos.X, BallPos.Y)) != FieldType.OpenGate &&
    //                    GetFieldType(new Point(BallPos.X, BallPos.Y)) != FieldType.Switch)
    //                {
    //                    Table.GameTable[BallPos.Y, BallPos.X] = FieldType.PaintedCanvas;
    //                }

    //                BallPos = new Point(BallPos.X + 1, BallPos.Y);
    //                BallMoved?.Invoke(this, BallPos);

    //            }

    //            else if (GetFieldType(new Point(BallPos.X + 1, BallPos.Y)) == FieldType.OpenGate)
    //            {
    //                Table.GameTable[BallPos.Y, BallPos.X] = FieldType.PaintedCanvas;
    //                BallPos = new Point(BallPos.X + 1, BallPos.Y);
    //                BallMoved?.Invoke(this, BallPos);
    //            }

    //            else if (GetFieldType(new Point(BallPos.X + 1, BallPos.Y)) == FieldType.Switch)
    //            {
    //                SwitchSequence();
    //                Table.GameTable[BallPos.Y, BallPos.X] = FieldType.PaintedCanvas;
    //                BallPos = new Point(BallPos.X + 1, BallPos.Y);
    //                BallMoved?.Invoke(this, BallPos);
    //            }

    //            //if canvas count == painted fields count -> es egy ajtoba leptunk -> win game

    //            break;

    //        case Direction.Left:

    //            if (!IsInside(new Point(BallPos.X - 1, BallPos.Y)))
    //            {
    //                return;
    //            }

    //            if (GetFieldType(new Point(BallPos.X - 1, BallPos.Y)) == FieldType.Wall)
    //            {
    //                IllegalMove?.Invoke(this, "Illegal move, there is a wall!");
    //                return;
    //            }

    //            else if (GetFieldType(new Point(BallPos.X - 1, BallPos.Y)) == FieldType.ClosedGate)
    //            {
    //                IllegalMove?.Invoke(this, "Illegal move, there is a closed gate!");
    //                return;
    //            }

    //            else if (GetFieldType(new Point(BallPos.X - 1, BallPos.Y)) == FieldType.Canvas ||
    //                GetFieldType(new Point(BallPos.X - 1, BallPos.Y)) == FieldType.Start ||
    //                GetFieldType(new Point(BallPos.X - 1, BallPos.Y)) == FieldType.PaintedCanvas)
    //            {
    //                if (GetFieldType(new Point(BallPos.X, BallPos.Y)) != FieldType.OpenGate &&
    //                    GetFieldType(new Point(BallPos.X, BallPos.Y)) != FieldType.Switch)
    //                {
    //                    Table.GameTable[BallPos.Y, BallPos.X] = FieldType.PaintedCanvas;
    //                }

    //                BallPos = new Point(BallPos.X - 1, BallPos.Y);
    //                BallMoved?.Invoke(this, BallPos);
    //            }

    //            else if (GetFieldType(new Point(BallPos.X - 1, BallPos.Y)) == FieldType.OpenGate)
    //            {
    //                Table.GameTable[BallPos.Y, BallPos.X] = FieldType.PaintedCanvas;
    //                BallPos = new Point(BallPos.X - 1, BallPos.Y);
    //                BallMoved?.Invoke(this, BallPos);
    //            }

    //            else if (GetFieldType(new Point(BallPos.X - 1, BallPos.Y)) == FieldType.Switch)
    //            {
    //                SwitchSequence();
    //                Table.GameTable[BallPos.Y, BallPos.X] = FieldType.PaintedCanvas;
    //                BallPos = new Point(BallPos.X - 1, BallPos.Y);
    //                BallMoved?.Invoke(this, BallPos);
    //            }

    //            break;

    //        case Direction.Up:

    //            if (!IsInside(new Point(BallPos.X, BallPos.Y - 1)))
    //            {
    //                return;
    //            }

    //            if (GetFieldType(new Point(BallPos.X, BallPos.Y - 1)) == FieldType.Wall)
    //            {
    //                IllegalMove?.Invoke(this, "Illegal move, there is a wall!");
    //                return;
    //            }

    //            else if (GetFieldType(new Point(BallPos.X, BallPos.Y - 1)) == FieldType.ClosedGate)
    //            {
    //                IllegalMove?.Invoke(this, "Illegal move, there is a closed gate!");
    //                return;
    //            }

    //            else if (GetFieldType(new Point(BallPos.X, BallPos.Y - 1)) == FieldType.Canvas ||
    //                    GetFieldType(new Point(BallPos.X, BallPos.Y - 1)) == FieldType.Start ||
    //                    GetFieldType(new Point(BallPos.X, BallPos.Y - 1)) == FieldType.PaintedCanvas)
    //            {
    //                if (GetFieldType(new Point(BallPos.X, BallPos.Y)) != FieldType.OpenGate &&
    //                    GetFieldType(new Point(BallPos.X, BallPos.Y)) != FieldType.Switch)
    //                {
    //                    Table.GameTable[BallPos.Y, BallPos.X] = FieldType.PaintedCanvas;
    //                }
    //                BallPos = new Point(BallPos.X, BallPos.Y - 1);
    //                BallMoved?.Invoke(this, BallPos);


    //            }

    //            else if (GetFieldType(new Point(BallPos.X, BallPos.Y - 1)) == FieldType.OpenGate)
    //            //mivel nem volt return es mar megvaltozott az erteke
    //            //(az elozo ifben) ezert ez a -1et vizsgalja ami index out of bounds
    //            //public FieldType GetFieldType(Point p)
    //            //{
    //            //    return Table.GameTable[p.Y, p.X]; ez itt p.Y -1 lesz az ellenorzesben ezert ott volt a hiba
    //            {
    //                Table.GameTable[BallPos.Y, BallPos.X] = FieldType.PaintedCanvas;
    //                BallPos = new Point(BallPos.X, BallPos.Y - 1);
    //                BallMoved?.Invoke(this, BallPos);
    //            }

    //            else if (GetFieldType(new Point(BallPos.X, BallPos.Y - 1)) == FieldType.Switch)
    //            {
    //                SwitchSequence();
    //                Table.GameTable[BallPos.Y, BallPos.X] = FieldType.PaintedCanvas;
    //                BallPos = new Point(BallPos.X, BallPos.Y - 1);
    //                BallMoved?.Invoke(this, BallPos);
    //            }

    //            break;

    //        case Direction.Down:

    //            if (!IsInside(new Point(BallPos.X, BallPos.Y + 1)))
    //            {
    //                return;
    //            }

    //            if (GetFieldType(new Point(BallPos.X, BallPos.Y + 1)) == FieldType.Wall)
    //            {
    //                IllegalMove?.Invoke(this, "Illegal move, there is a wall!");
    //                return;
    //            }

    //            else if (GetFieldType(new Point(BallPos.X, BallPos.Y + 1)) == FieldType.ClosedGate)
    //            {
    //                IllegalMove?.Invoke(this, "Illegal move, there is a closed gate!");
    //                return;
    //            }

    //            else if (GetFieldType(new Point(BallPos.X, BallPos.Y + 1)) == FieldType.Canvas ||
    //                    GetFieldType(new Point(BallPos.X, BallPos.Y + 1)) == FieldType.Start ||
    //                    GetFieldType(new Point(BallPos.X, BallPos.Y + 1)) == FieldType.PaintedCanvas)
    //            {
    //                if (GetFieldType(new Point(BallPos.X, BallPos.Y)) != FieldType.OpenGate &&   // X, Y lehetne amugy canvas, start amit ki kell szineznunk de ezt nem szabad
    //                    GetFieldType(new Point(BallPos.X, BallPos.Y)) != FieldType.Switch)
    //                {
    //                    Table.GameTable[BallPos.Y, BallPos.X] = FieldType.PaintedCanvas;
    //                }



    //                BallPos = new Point(BallPos.X, BallPos.Y + 1);
    //                BallMoved?.Invoke(this, BallPos);
    //            }

    //            else if (GetFieldType(new Point(BallPos.X, BallPos.Y + 1)) == FieldType.OpenGate)
    //            {
    //                Table.GameTable[BallPos.Y, BallPos.X] = FieldType.PaintedCanvas;
    //                BallPos = new Point(BallPos.X, BallPos.Y + 1);
    //                BallMoved?.Invoke(this, BallPos);
    //            }

    //            else if (GetFieldType(new Point(BallPos.X, BallPos.Y + 1)) == FieldType.Switch)
    //            {
    //                SwitchSequence();
    //                Table.GameTable[BallPos.Y, BallPos.X] = FieldType.PaintedCanvas;
    //                BallPos = new Point(BallPos.X, BallPos.Y + 1);
    //                BallMoved?.Invoke(this, BallPos);
    //            }

    //            break;
    //    }

    //    if (IsGameFinished())
    //    {
    //        GameFinished?.Invoke(this, EventArgs.Empty);
    //    }
    //}
}
