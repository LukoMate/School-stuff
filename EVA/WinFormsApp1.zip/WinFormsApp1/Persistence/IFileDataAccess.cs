﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1.Persistence
{
    public interface IFileDataAccess
    {
        Task<Table> LoadAsync(String path);
        Task<Table> SaveAsync(String path, Table table);
    }
}
